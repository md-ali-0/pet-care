import { object, string } from "zod";

export const resetPasswordSchema = object({
  newPassword: string({ required_error: "Password is required" })
    .min(1, "Password is required")
    .min(6, "Password must be more than 6 characters")
    .max(32, "Password must be less than 32 characters"),
});
