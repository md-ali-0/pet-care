import MyProfileContnet from "@/components/my-account/my-profile-contnet";
import MyProfileHeader from "@/components/my-account/my-profile-header";

export default function ProfilePage() {
  return (
    <div>
      <MyProfileHeader />
      <MyProfileContnet />
    </div>
  );
}
