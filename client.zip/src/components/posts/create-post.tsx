"use client";

import { Button } from "@nextui-org/button";
import { Card, CardBody, CardHeader } from "@nextui-org/card";
import { Input, Textarea } from "@nextui-org/input";
import { Modal, ModalBody, ModalFooter, ModalHeader } from "@nextui-org/modal";
import { Select, SelectItem } from "@nextui-org/select";
import { useState } from "react";
import { LuImage, LuPen, LuSmile, LuVideo } from "react-icons/lu";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css"; // Import Quill's styles

export default function CreatePost() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [postContent, setPostContent] = useState(""); // Rich Text content
  const [selectedCategory, setSelectedCategory] = useState(""); // Category selection
  const [image, setImage] = useState<File | null>(null); // Image state

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImage(e.target.files[0]);
    }
  };

  const handlePostSubmit = () => {
    // Handle form submission, e.g., send data to the backend
    console.log({ postContent, selectedCategory, image });
    closeModal();
  };

  return (
    <>
      {/* Main Card for Post Creation */}
      <Card className="mb-6">
        <CardHeader className="flex items-center p-4">
          <LuPen className="text-blue-500 mr-3" />
          <h2 className="text-lg font-semibold">Create Post</h2>
        </CardHeader>
        <CardBody className="p-4">
          <Textarea
            isReadOnly
            placeholder="What's on your mind?"
            onFocus={openModal}
          />
          <div className="flex justify-between mt-4">
            <Button
              startContent={<LuVideo className="mr-2 text-red-500" />}
              variant="light"
            >
              Live Video
            </Button>
            <Button
              startContent={<LuImage className="mr-2 text-green-500" />}
              variant="light"
            >
              Photo/Video
            </Button>
            <Button
              startContent={<LuSmile className="mr-2 text-orange-500" />}
              variant="light"
            >
              Feeling/Activity
            </Button>
            <Button color="primary" onPress={openModal}>
              Post
            </Button>
          </div>
        </CardBody>
      </Card>

      {/* Modal for Rich Text Editor, Image Upload & Category Selection */}
      <Modal open={isModalOpen} onClose={closeModal}>
        <ModalHeader>
          <h3>Create Post</h3>
        </ModalHeader>
        <ModalBody>
          <div className="space-y-4">
            {/* Rich Text Editor */}
            <ReactQuill
              placeholder="Write your story or tip here..."
              theme="snow"
              value={postContent}
              onChange={setPostContent}
            />

            {/* Category Selection */}
            <Select
              placeholder="Select Category"
              value={selectedCategory}
              onChange={setSelectedCategory}
            >
              <SelectItem value="Tip">Tip</SelectItem>
              <SelectItem value="Story">Story</SelectItem>
            </Select>

            {/* Image Upload */}
            <div>
              <label
                className="block font-semibold mb-2"
                htmlFor="image-upload"
              >
                Attach Image
              </label>
              <Input
                accept="image/*"
                id="image-upload"
                radius="sm"
                type="file"
                onChange={handleImageChange}
              />
            </div>
          </div>
        </ModalBody>
        <ModalFooter>
          <Button color="danger" variant="shadow" onPress={closeModal}>
            Cancel
          </Button>
          <Button color="primary" variant="shadow" onPress={handlePostSubmit}>
            Post
          </Button>
        </ModalFooter>
      </Modal>
    </>
  );
}
