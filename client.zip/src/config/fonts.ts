import { Jost } from "next/font/google";

export const fontJost = Jost({
  subsets: ["latin"],
  variable: "--font-jost",
});
